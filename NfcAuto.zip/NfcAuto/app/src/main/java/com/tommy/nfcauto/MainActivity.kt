package com.tommy.nfcauto

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.text.format.DateFormat
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.nio.charset.Charset
import java.util.Date

class MainActivity : AppCompatActivity() {

    private var nfcAdapter: NfcAdapter? = null
    private var writeMode = false
    private var pendingWriteRecords: Array<NdefRecord>? = null

    private val historyLog = mutableListOf<String>()

    // Types de contenu disponibles pour l'écriture
    private val TYPES = listOf("SMS", "Appel", "Lien Web", "Email", "Wi-Fi", "Contact", "Texte libre")

    private lateinit var radioRead: RadioButton
    private lateinit var radioWrite: RadioButton
    private lateinit var readBlock: LinearLayout
    private lateinit var writeBlock: LinearLayout
    private lateinit var permBlock: LinearLayout
    private lateinit var permText: TextView
    private lateinit var btnGrantPerm: Button
    private lateinit var spinnerType: Spinner
    private lateinit var btnPrepareWrite: Button
    private lateinit var writeStatus: TextView
    private lateinit var readStatus: TextView
    private lateinit var historyText: TextView

    // Groupes de champs
    private lateinit var fieldGroups: Map<String, LinearLayout>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        radioRead = findViewById(R.id.radioRead)
        radioWrite = findViewById(R.id.radioWrite)
        readBlock = findViewById(R.id.readBlock)
        writeBlock = findViewById(R.id.writeBlock)
        permBlock = findViewById(R.id.permBlock)
        permText = findViewById(R.id.permText)
        btnGrantPerm = findViewById(R.id.btnGrantPerm)
        spinnerType = findViewById(R.id.spinnerType)
        btnPrepareWrite = findViewById(R.id.btnPrepareWrite)
        writeStatus = findViewById(R.id.writeStatus)
        readStatus = findViewById(R.id.readStatus)
        historyText = findViewById(R.id.historyText)

        fieldGroups = mapOf(
            "SMS" to findViewById(R.id.fieldsSms),
            "Appel" to findViewById(R.id.fieldsTel),
            "Lien Web" to findViewById(R.id.fieldsUrl),
            "Email" to findViewById(R.id.fieldsMail),
            "Wi-Fi" to findViewById(R.id.fieldsWifi),
            "Contact" to findViewById(R.id.fieldsVcard),
            "Texte libre" to findViewById(R.id.fieldsText)
        )

        spinnerType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, TYPES)
        spinnerType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                showFieldsFor(TYPES[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        showFieldsFor(TYPES[0])

        radioRead.setOnClickListener { setMode(false) }
        radioWrite.setOnClickListener { setMode(true) }

        btnPrepareWrite.setOnClickListener { prepareWrite() }
        btnGrantPerm.setOnClickListener { requestSmsPermission() }

        refreshPermBanner()

        if (nfcAdapter == null) {
            writeStatus.text = "⚠️ Cet appareil ne possède pas de puce NFC."
        }

        handleIntent(intent)
    }

    private fun setMode(write: Boolean) {
        writeMode = write
        readBlock.visibility = if (write) View.GONE else View.VISIBLE
        writeBlock.visibility = if (write) View.VISIBLE else View.GONE
        pendingWriteRecords = null
        writeStatus.text = ""
    }

    private fun showFieldsFor(type: String) {
        fieldGroups.forEach { (key, group) -> group.visibility = if (key == type) View.VISIBLE else View.GONE }
    }

    // ---------- Permissions ----------

    private fun hasSmsPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    private fun requestSmsPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.SEND_SMS, android.Manifest.permission.CALL_PHONE), 101)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshPermBanner()
    }

    private fun refreshPermBanner() {
        if (!hasSmsPermission()) {
            permBlock.visibility = View.VISIBLE
            permText.text = "Autorisation SMS requise pour envoyer les messages automatiquement au scan d'un tag. Sans elle, l'app ouvrira l'application Messages normalement."
        } else {
            permBlock.visibility = View.GONE
        }
    }

    // ---------- Cycle de vie / dispatch NFC premier plan ----------

    override fun onResume() {
        super.onResume()
        val adapter = nfcAdapter ?: return
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_MUTABLE else 0
        )
        val ndefFilter = IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED)
        val tagFilter = IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED)
        adapter.enableForegroundDispatch(this, pendingIntent, arrayOf(ndefFilter, tagFilter), null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        val action = intent.action ?: return
        if (action != NfcAdapter.ACTION_NDEF_DISCOVERED && action != NfcAdapter.ACTION_TAG_DISCOVERED) return

        val tag: Tag? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        else
            @Suppress("DEPRECATION") intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)

        if (writeMode) {
            if (tag != null) writeTag(tag) else log("❌ Tag introuvable pour l'écriture.")
            return
        }

        // Mode lecture : on récupère les messages NDEF
        val rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
        if (rawMsgs == null || rawMsgs.isEmpty()) {
            log("📭 Tag lu, aucune donnée NDEF.")
            return
        }
        val message = rawMsgs[0] as NdefMessage
        for (record in message.records) {
            handleRecord(record)
        }
    }

    // ---------- Traitement d'un enregistrement lu ----------

    private fun handleRecord(record: NdefRecord) {
        val uri: String? = when {
            record.tnf == NdefRecord.TNF_WELL_KNOWN && record.type.contentEquals(NdefRecord.RTD_URI) ->
                record.toUri()?.toString()
            record.tnf == NdefRecord.TNF_ABSOLUTE_URI -> String(record.type, Charset.forName("UTF-8"))
            else -> null
        }

        if (uri == null) {
            if (record.tnf == NdefRecord.TNF_WELL_KNOWN && record.type.contentEquals(NdefRecord.RTD_TEXT)) {
                log("📝 Texte lu : " + decodeTextRecord(record))
            } else if (record.tnf == NdefRecord.TNF_MIME_MEDIA) {
                log("📇 Contenu (${String(record.type)}) lu.")
            }
            return
        }

        when {
            uri.startsWith("sms:") || uri.startsWith("smsto:") -> autoSendSms(uri)
            uri.startsWith("tel:") -> autoCall(uri)
            else -> openGeneric(uri)
        }
    }

    private fun decodeTextRecord(record: NdefRecord): String {
        val payload = record.payload
        val languageCodeLength = payload[0].toInt() and 0x3F
        return String(payload, languageCodeLength + 1, payload.size - languageCodeLength - 1, Charset.forName("UTF-8"))
    }

    // ---------- Envoi automatique ----------

    private fun autoSendSms(uri: String) {
        val u = Uri.parse(uri)
        val number = u.schemeSpecificPart.substringBefore("?")
        val body = u.getQueryParameter("body") ?: ""

        if (!hasSmsPermission()) {
            log("⚠️ Permission SMS manquante — ouverture de l'app Messages.")
            openGeneric(uri)
            refreshPermBanner()
            return
        }

        try {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                getSystemService(SmsManager::class.java)
            else
                @Suppress("DEPRECATION") SmsManager.getDefault()

            if (body.isNotEmpty()) {
                val parts = smsManager.divideMessage(body)
                smsManager.sendMultipartTextMessage(number, null, parts, null, null)
            } else {
                smsManager.sendTextMessage(number, null, "", null, null)
            }
            log("✅ SMS envoyé automatiquement à $number")
            Toast.makeText(this, "Message envoyé à $number", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            log("❌ Échec de l'envoi automatique : ${e.message}")
        }
    }

    private fun autoCall(uri: String) {
        val hasCallPerm = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        if (hasCallPerm) {
            try {
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse(uri)))
                log("📞 Appel automatique lancé ($uri)")
                return
            } catch (e: Exception) {
                log("❌ Échec de l'appel automatique : ${e.message}")
            }
        }
        openGeneric(uri)
    }

    private fun openGeneric(uri: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            log("🔗 Ouverture : $uri")
        } catch (e: Exception) {
            log("❌ Impossible d'ouvrir : $uri")
        }
    }

    // ---------- Écriture de tags ----------

    private fun prepareWrite() {
        val type = spinnerType.selectedItem as String
        val records: Array<NdefRecord> = try {
            when (type) {
                "SMS" -> {
                    val phone = findViewById<EditText>(R.id.smsPhone).text.toString()
                    val body = findViewById<EditText>(R.id.smsBody).text.toString()
                    val uri = "sms:$phone" + if (body.isNotEmpty()) "?body=" + Uri.encode(body) else ""
                    arrayOf(NdefRecord.createUri(uri))
                }
                "Appel" -> {
                    val phone = findViewById<EditText>(R.id.telPhone).text.toString()
                    arrayOf(NdefRecord.createUri("tel:$phone"))
                }
                "Lien Web" -> {
                    var url = findViewById<EditText>(R.id.urlValue).text.toString()
                    if (!url.startsWith("http")) url = "https://$url"
                    arrayOf(NdefRecord.createUri(url))
                }
                "Email" -> {
                    val to = findViewById<EditText>(R.id.mailTo).text.toString()
                    val subject = findViewById<EditText>(R.id.mailSubject).text.toString()
                    val body = findViewById<EditText>(R.id.mailBody).text.toString()
                    val uri = "mailto:$to?subject=${Uri.encode(subject)}&body=${Uri.encode(body)}"
                    arrayOf(NdefRecord.createUri(uri))
                }
                "Wi-Fi" -> {
                    val ssid = findViewById<EditText>(R.id.wifiSsid).text.toString()
                    val pass = findViewById<EditText>(R.id.wifiPass).text.toString()
                    val text = "WIFI:T:WPA;S:$ssid;P:$pass;;"
                    arrayOf(NdefRecord.createTextRecord(null, text))
                }
                "Contact" -> {
                    val name = findViewById<EditText>(R.id.vcardName).text.toString()
                    val phone = findViewById<EditText>(R.id.vcardPhone).text.toString()
                    val email = findViewById<EditText>(R.id.vcardEmail).text.toString()
                    val vcard = "BEGIN:VCARD\nVERSION:3.0\nFN:$name\nTEL:$phone\nEMAIL:$email\nEND:VCARD"
                    arrayOf(NdefRecord.createMime("text/vcard", vcard.toByteArray(Charset.forName("UTF-8"))))
                }
                else -> {
                    val text = findViewById<EditText>(R.id.freeText).text.toString()
                    arrayOf(NdefRecord.createTextRecord(null, text))
                }
            }
        } catch (e: Exception) {
            writeStatus.text = "❌ Champs invalides."
            return
        }

        pendingWriteRecords = records
        writeStatus.text = "📡 Approche un tag NFC vierge pour écrire ce contenu…"
    }

    private fun writeTag(tag: Tag) {
        val records = pendingWriteRecords
        if (records == null) {
            writeStatus.text = "Prépare d'abord le contenu avant d'approcher un tag."
            return
        }
        val message = NdefMessage(records)
        try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                if (!ndef.isWritable) {
                    writeStatus.text = "❌ Ce tag n'est pas inscriptible."
                    ndef.close()
                    return
                }
                if (ndef.maxSize < message.toByteArray().size) {
                    writeStatus.text = "❌ Contenu trop volumineux pour ce tag."
                    ndef.close()
                    return
                }
                ndef.writeNdefMessage(message)
                ndef.close()
            } else {
                val formatable = NdefFormatable.get(tag)
                if (formatable != null) {
                    formatable.connect()
                    formatable.format(message)
                    formatable.close()
                } else {
                    writeStatus.text = "❌ Ce tag n'est pas compatible NDEF."
                    return
                }
            }
            writeStatus.text = "✅ Tag écrit avec succès !"
            log("✍️ Tag écrit (${spinnerType.selectedItem})")
            pendingWriteRecords = null
        } catch (e: Exception) {
            writeStatus.text = "❌ Échec de l'écriture : ${e.message}"
        }
    }

    // ---------- Historique ----------

    private fun log(entry: String) {
        val time = DateFormat.format("HH:mm:ss", Date())
        historyLog.add(0, "[$time] $entry")
        if (historyLog.size > 30) historyLog.removeAt(historyLog.size - 1)
        historyText.text = historyLog.joinToString("\n")
        runOnUiThread {
            if (!writeMode) readStatus.text = entry
        }
    }
}
