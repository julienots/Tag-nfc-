package com.tommy.nfcauto

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.Charset

/**
 * L'interface utilisateur est entièrement fournie par assets/index.html (WebView).
 * Ce fichier fait le pont entre la page web et les API Android natives :
 * NFC (lecture/écriture réelle), envoi de SMS (SmsManager), appel (ACTION_CALL).
 * C'est ici, et seulement ici, que le SMS est réellement envoyé — le navigateur
 * seul ne peut jamais le faire, d'où la fusion app web + app Android en un seul projet.
 */
class MainActivity : AppCompatActivity() {

    private var nfcAdapter: NfcAdapter? = null
    private lateinit var webView: WebView

    // Mode courant piloté depuis le JS (onglet actif) : "read" ou "write"
    @Volatile private var writeMode = false
    @Volatile private var autoActionEnabled = true
    @Volatile private var pendingWriteRecords: Array<NdefRecord>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        webView = findViewById(R.id.webView)
        setupWebView()
        webView.loadUrl("file:///android_asset/index.html")

        handleIntent(intent)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")
    }

    private fun runJs(script: String) {
        runOnUiThread { webView.evaluateJavascript(script, null) }
    }

    /** Échappe une chaîne pour l'injecter en tant que littéral JS sûr. */
    private fun js(s: String): String = JSONObject.quote(s)

    // =====================================================================
    // Pont JavaScript -> Kotlin, exposé à index.html sous window.AndroidBridge
    // =====================================================================
    inner class Bridge {

        @JavascriptInterface
        fun hasSmsPermission(): Boolean = hasSmsPermissionInternal()

        @JavascriptInterface
        fun requestSmsPermission() {
            runOnUiThread {
                ActivityCompat.requestPermissions(
                    this@MainActivity,
                    arrayOf(android.Manifest.permission.SEND_SMS, android.Manifest.permission.CALL_PHONE),
                    101
                )
            }
        }

        /** Appelé quand l'utilisateur bascule entre l'onglet "Écrire" et "Lire" dans la page. */
        @JavascriptInterface
        fun setMode(mode: String) {
            writeMode = mode == "write"
            if (!writeMode) pendingWriteRecords = null
        }

        /** Bascule de la page (SMS/appel réellement déclenchés à la lecture, ou juste affichés). */
        @JavascriptInterface
        fun setAutoAction(enabled: Boolean) {
            autoActionEnabled = enabled
        }

        @JavascriptInterface
        fun cancelWrite() {
            pendingWriteRecords = null
        }

        /**
         * Reçoit le type de modèle + les champs du formulaire (JSON) depuis le JS,
         * construit les NdefRecord correspondants et attend qu'un tag soit approché.
         */
        @JavascriptInterface
        fun prepareWrite(type: String, fieldsJson: String) {
            try {
                val f = JSONObject(fieldsJson)
                val records: Array<NdefRecord> = when (type) {
                    "sms" -> {
                        val phone = f.optString("phone")
                        val msg = f.optString("msg")
                        val uri = "sms:$phone" + if (msg.isNotEmpty()) "?body=" + Uri.encode(msg) else ""
                        arrayOf(NdefRecord.createUri(uri))
                    }
                    "call" -> arrayOf(NdefRecord.createUri("tel:${f.optString("phone")}"))
                    "url" -> {
                        var url = f.optString("url")
                        if (!url.startsWith("http")) url = "https://$url"
                        arrayOf(NdefRecord.createUri(url))
                    }
                    "mail" -> {
                        val to = f.optString("to")
                        val subject = f.optString("subject")
                        val body = f.optString("body")
                        val uri = "mailto:$to?subject=${Uri.encode(subject)}&body=${Uri.encode(body)}"
                        arrayOf(NdefRecord.createUri(uri))
                    }
                    "wifi" -> {
                        val ssid = f.optString("ssid")
                        val pass = f.optString("pass")
                        val sec = f.optString("sec", "WPA")
                        arrayOf(NdefRecord.createTextRecord(null, "WIFI:T:$sec;S:$ssid;P:$pass;;"))
                    }
                    "vcard" -> {
                        val vcard = "BEGIN:VCARD\nVERSION:3.0\nFN:${f.optString("name")}\nORG:${f.optString("org")}\nTEL:${f.optString("phone")}\nEMAIL:${f.optString("email")}\nEND:VCARD"
                        arrayOf(NdefRecord.createMime("text/vcard", vcard.toByteArray(Charset.forName("UTF-8"))))
                    }
                    "app" -> arrayOf(NdefRecord.createUri(f.optString("resolvedUrl")))
                    "geo" -> arrayOf(NdefRecord.createUri("geo:${f.optString("lat")},${f.optString("lng")}"))
                    "poster" -> {
                        var url = f.optString("url")
                        if (!url.startsWith("http")) url = "https://$url"
                        arrayOf(NdefRecord.createTextRecord(null, f.optString("title")), NdefRecord.createUri(url))
                    }
                    else -> arrayOf(NdefRecord.createTextRecord(null, f.optString("text")))
                }
                pendingWriteRecords = records
                writeMode = true
            } catch (e: Exception) {
                runJs("onWriteResult(false, ${js("Champs invalides")})")
            }
        }

        /** Bouton "Rejouer l'action" dans l'onglet Lire : redéclenche réellement le SMS/appel/lien. */
        @JavascriptInterface
        fun triggerManualAction(uri: String) {
            runOnUiThread {
                when {
                    uri.startsWith("sms:") || uri.startsWith("smsto:") -> autoSendSms(uri)
                    uri.startsWith("tel:") -> autoCall(uri)
                    else -> openGeneric(uri)
                }
            }
        }
    }

    private fun hasSmsPermissionInternal(): Boolean =
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    private fun hasCallPermissionInternal(): Boolean =
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

    // ---------- Cycle de vie / dispatch NFC premier plan ----------

    override fun onResume() {
        super.onResume()
        val adapter = nfcAdapter ?: return
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_MUTABLE else 0
        )
        val ndefFilter = IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED)
        val tagFilter = IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED)
        adapter.enableForegroundDispatch(this, pendingIntent, arrayOf(ndefFilter, tagFilter), null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        runJs("onPermissionResult(${hasSmsPermissionInternal()})")
    }

    private fun handleIntent(intent: Intent) {
        val action = intent.action ?: return
        if (action != NfcAdapter.ACTION_NDEF_DISCOVERED && action != NfcAdapter.ACTION_TAG_DISCOVERED) return

        val tag: Tag? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        else
            @Suppress("DEPRECATION") intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)

        // Mode écriture : un contenu a été préparé depuis la page HTML, on écrit dès qu'un tag est approché.
        if (writeMode && pendingWriteRecords != null) {
            if (tag != null) writeTag(tag) else runJs("onWriteResult(false, ${js("Tag introuvable")})")
            return
        }

        // Mode lecture : on décode le tag et on informe la page HTML pour l'affichage.
        val rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
        val serial = tag?.id?.joinToString("") { String.format("%02X", it) } ?: "inconnu"

        if (rawMsgs == null || rawMsgs.isEmpty()) {
            runJs("onNativeTagRead(${js(serial)}, [])")
            return
        }

        val message = rawMsgs[0] as NdefMessage
        val recordsJson = JSONArray()
        for (record in message.records) recordsJson.put(recordToJson(record))
        runJs("onNativeTagRead(${js(serial)}, $recordsJson)")

        if (autoActionEnabled) {
            for (record in message.records) {
                val uri = recordUri(record) ?: continue
                when {
                    uri.startsWith("sms:") || uri.startsWith("smsto:") -> autoSendSms(uri)
                    uri.startsWith("tel:") -> autoCall(uri)
                    else -> openGeneric(uri)
                }
                break
            }
        }
    }

    private fun recordUri(record: NdefRecord): String? = when {
        record.tnf == NdefRecord.TNF_WELL_KNOWN && record.type.contentEquals(NdefRecord.RTD_URI) -> record.toUri()?.toString()
        record.tnf == NdefRecord.TNF_ABSOLUTE_URI -> String(record.type, Charset.forName("UTF-8"))
        else -> null
    }

    private fun recordToJson(record: NdefRecord): JSONObject {
        val obj = JSONObject()
        val uri = recordUri(record)
        when {
            uri != null -> { obj.put("recordType", "url"); obj.put("value", uri) }
            record.tnf == NdefRecord.TNF_WELL_KNOWN && record.type.contentEquals(NdefRecord.RTD_TEXT) -> {
                obj.put("recordType", "text"); obj.put("value", decodeTextRecord(record))
            }
            record.tnf == NdefRecord.TNF_MIME_MEDIA -> {
                obj.put("recordType", "mime")
                obj.put("mediaType", String(record.type))
                obj.put("value", String(record.payload, Charset.forName("UTF-8")))
            }
            else -> { obj.put("recordType", "unknown"); obj.put("value", "") }
        }
        return obj
    }

    private fun decodeTextRecord(record: NdefRecord): String {
        val payload = record.payload
        val languageCodeLength = payload[0].toInt() and 0x3F
        return String(payload, languageCodeLength + 1, payload.size - languageCodeLength - 1, Charset.forName("UTF-8"))
    }

    // ---------- Envoi automatique réel (SmsManager / ACTION_CALL) ----------

    private fun autoSendSms(uri: String) {
        val u = Uri.parse(uri)
        val number = u.schemeSpecificPart.substringBefore("?")
        val body = u.getQueryParameter("body") ?: ""

        if (!hasSmsPermissionInternal()) {
            runJs("logReadAction(${js("⚠️ Permission SMS manquante — ouverture de l'app Messages.")})")
            openGeneric(uri)
            return
        }
        try {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                getSystemService(SmsManager::class.java)
            else
                @Suppress("DEPRECATION") SmsManager.getDefault()

            if (body.isNotEmpty()) {
                val parts = smsManager.divideMessage(body)
                smsManager.sendMultipartTextMessage(number, null, parts, null, null)
            } else {
                smsManager.sendTextMessage(number, null, "", null, null)
            }
            runJs("logReadAction(${js("✅ SMS envoyé automatiquement à $number")})")
            runOnUiThread { Toast.makeText(this, "Message envoyé à $number", Toast.LENGTH_SHORT).show() }
        } catch (e: Exception) {
            runJs("logReadAction(${js("❌ Échec de l'envoi automatique : ${e.message}")})")
        }
    }

    private fun autoCall(uri: String) {
        if (hasCallPermissionInternal()) {
            try {
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse(uri)))
                runJs("logReadAction(${js("📞 Appel automatique lancé ($uri)")})")
                return
            } catch (e: Exception) {
                runJs("logReadAction(${js("❌ Échec de l'appel automatique : ${e.message}")})")
            }
        }
        openGeneric(uri)
    }

    private fun openGeneric(uri: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            runJs("logReadAction(${js("🔗 Ouverture : $uri")})")
        } catch (e: Exception) {
            runJs("logReadAction(${js("❌ Impossible d'ouvrir : $uri")})")
        }
    }

    // ---------- Écriture réelle du tag ----------

    private fun writeTag(tag: Tag) {
        val records = pendingWriteRecords ?: return
        val message = NdefMessage(records)
        try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                if (!ndef.isWritable) {
                    runJs("onWriteResult(false, ${js("Ce tag n'est pas inscriptible.")})")
                    ndef.close(); return
                }
                if (ndef.maxSize < message.toByteArray().size) {
                    runJs("onWriteResult(false, ${js("Contenu trop volumineux pour ce tag.")})")
                    ndef.close(); return
                }
                ndef.writeNdefMessage(message)
                ndef.close()
            } else {
                val formatable = NdefFormatable.get(tag)
                if (formatable != null) {
                    formatable.connect(); formatable.format(message); formatable.close()
                } else {
                    runJs("onWriteResult(false, ${js("Ce tag n'est pas compatible NDEF.")})")
                    return
                }
            }
            runJs("onWriteResult(true, ${js("Tag écrit avec succès !")})")
            pendingWriteRecords = null
        } catch (e: Exception) {
            runJs("onWriteResult(false, ${js("Échec de l'écriture : ${e.message}")})")
        }
    }
}
