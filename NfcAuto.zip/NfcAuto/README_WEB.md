# NFC Auto — app unique (WebView + natif)

L'interface (`app/src/main/assets/index.html`) et la logique Android (`MainActivity.kt`)
ne font plus qu'un seul projet, plus une simple page web à côté :

- `MainActivity.kt` charge `index.html` dans une **WebView plein écran** (pas d'UI XML classique).
- Un pont `AndroidBridge` (JavaScript ↔ Kotlin) permet à la page de :
  - préparer l'écriture d'un tag (`AndroidBridge.prepareWrite(type, champsJson)`) — l'écriture NFC réelle est faite en Kotlin ;
  - être notifiée en direct d'un tag lu (`onNativeTagRead(...)`, appelé depuis Kotlin) ;
  - déclencher un envoi de SMS ou un appel **réel** via `SmsManager` / `ACTION_CALL` — pas une simple ouverture d'appli, un vrai envoi automatique, comme le faisait déjà `MainActivity.kt` avant la fusion avec la page HTML.
- Les permissions `SEND_SMS` / `CALL_PHONE` restent gérées nativement ; la page affiche une bannière si elles manquent et un bouton "Autoriser" qui déclenche la demande native.

Il n'y a donc plus besoin d'héberger `index.html` séparément (GitHub Pages) pour avoir l'envoi de SMS automatique : tout se passe dans l'APK, en local, avec les vraies API Android.
